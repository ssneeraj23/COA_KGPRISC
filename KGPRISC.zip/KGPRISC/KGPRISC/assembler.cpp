#include <bits/stdc++.h>
using namespace std;

map<string, string> opcode;
map<string, string> funct;
map<string, string> regs;

map<string, int> labelMap;

long long PC = 0;

void insertCodes()
{

    opcode["add"] = "000001";
    opcode["comp"] = "000001";
    opcode["diff"] = "000001";
    opcode["and"] = "000010";
    opcode["xor"] = "000010";
    opcode["shll"] = "000011";
    opcode["shrl"] = "000011";
    opcode["shllv"] = "000011";
    opcode["shrlv"] = "000011";
    opcode["shra"] = "000011";
    opcode["shrav"] = "000011";

    opcode["lw"] = "100011";
    opcode["sw"] = "101011";

    opcode["addi"] = "100100";
    opcode["compi"] = "100101";

    opcode["b"] = "000101";
    opcode["bl"] = "000110";
    opcode["bcy"] = "000101";
    opcode["bncy"] = "000101";

    opcode["br"] = "000100";
    opcode["bltz"] = "000100";
    opcode["bz"] = "000100";
    opcode["bnz"] = "000100";

    funct["add"] = "000001";
    funct["comp"] = "000010";
    funct["diff"] = "000011";
    funct["and"] = "000001";
    funct["xor"] = "000010";
    funct["shll"] = "000000";
    funct["shrl"] = "000001";
    funct["shllv"] = "000010";
    funct["shrlv"] = "000011";
    funct["shra"] = "000100";
    funct["shrav"] = "000101";

    regs["$zero"] = regs["$0"] = "00000";
    regs["$at"] = regs["$1"] = "00001";
    regs["$v0"] = regs["$2"] = "00010";
    regs["$v1"] = regs["$3"] = "00011";
    regs["$a0"] = regs["$4"] = "00100";
    regs["$a1"] = regs["$5"] = "00101";
    regs["$a2"] = regs["$6"] = "00110";
    regs["$a3"] = regs["$7"] = "00111";
    regs["$t0"] = regs["$8"] = "01000";
    regs["$t1"] = regs["$9"] = "01001";
    regs["$t2"] = regs["$10"] = "01010";
    regs["$t3"] = regs["$11"] = "01011";
    regs["$t4"] = regs["$12"] = "01100";
    regs["$t5"] = regs["$13"] = "01101";
    regs["$t6"] = regs["$14"] = "01110";
    regs["$t7"] = regs["$15"] = "01111";
    regs["$s0"] = regs["$16"] = "10000";
    regs["$s1"] = regs["$17"] = "10001";
    regs["$s2"] = regs["$18"] = "10010";
    regs["$s3"] = regs["$19"] = "10011";
    regs["$s4"] = regs["$20"] = "10100";
    regs["$s5"] = regs["$21"] = "10101";
    regs["$s6"] = regs["$22"] = "10110";
    regs["$s7"] = regs["$23"] = "10111";
    regs["$t8"] = regs["$24"] = "11000";
    regs["$t9"] = regs["$25"] = "11001";
    regs["$k0"] = regs["$26"] = "11010";
    regs["$k1"] = regs["$27"] = "11011";
    regs["$gp"] = regs["$28"] = "11100";
    regs["$sp"] = regs["$29"] = "11101";
    regs["$fp"] = regs["$30"] = "11110";
    regs["$ra"] = regs["$31"] = "11111";
}

void parseLabel(string fileName)
{

    ifstream inFile;
    inFile.open(fileName);

    long long pc = 0;
    for (string line; getline(inFile, line);)
    {

        if (line == "" || line[0] == '#')
            continue;

        int found = 0;
        string label = "";

        for (int i = 0; i < line.size(); ++i)
        {
            if (line[i] == ':')
            {
                found = 1;
                break;
            }
            label += line[i];
        }
        if (found)
        {
            labelMap[label] = pc;
        }
        else
        {
            pc += 1;
        }
    }
}

string getCode(string line)
{

    string code = "";
    string op = "";

    int opEnd = 0;
    for (int i = 0; i < line.size(); ++i)
    {
        if (line[i] == ' ')
        {
            opEnd = i;
            break;
        }
        op += line[i];
    }

    if (opcode[op] == "000001" || opcode[op] == "000010" || opcode[op] == "000011" || op == "addi" || op == "compi")
    {

        int op2End = opEnd + 1;
        string op2 = "";
        for (int i = opEnd + 1; i < line.size(); ++i)
        {
            if (line[i] == ',')
            {
                op2End = i;
                break;
            }
            op2 += line[i];
        }
        while (line[op2End + 1] == ' ')
        {
            op2End++;
        }
        int op3End = op2End + 1;
        string op3 = "";

        for (int i = op2End + 1; i < line.size(); ++i)
        {
            if (line[i] == '\n' || line[i] == ' ')
            {
                op3End = i;
                break;
            }
            op3 += line[i];
        }

        code += opcode[op];
        code += regs[op2];

        if (op == "shll" || op == "shrl" || op == "shra")
        {
            code += "0000000000";
            const char *op3_const = op3.c_str();
            code += bitset<5>(atoi(op3_const)).to_string();
            code += funct[op];
        }
        else if (op == "addi" || op == "compi")
        {
            code += "00000";
            const char *op3_const = op3.c_str();
            code += bitset<16>(atoi(op3_const)).to_string();
        }
        else
        {
            code += regs[op3];
            code += "0000000000";
            code += funct[op];
        }
    }
    else if (op == "lw" || op == "sw")
    {

        int rtEnd = opEnd + 1;
        string rt = "";

        for (int i = opEnd + 1; i < line.size(); ++i)
        {
            if (line[i] == ',')
            {
                rtEnd = i;
                break;
            }
            rt += line[i];
        }

        string imm = "";
        int immEnd = rtEnd + 1;

        for (int i = rtEnd + 1; i < line.size(); ++i)
        {
            if (line[i] == '(')
            {
                immEnd = i;
                break;
            }
            imm += line[i];
        }
        string rs = "";
        for (int i = immEnd + 1; i < line.size(); ++i)
        {
            if (line[i] == ')')
                break;
            rs += line[i];
        }
        code += opcode[op];
        const char *imm_const = imm.c_str();
        code += regs[rs];
        code += regs[rt];
        code += bitset<16>(atoi(imm_const)).to_string();
    }

    return code;
}

int main()
{

    string fileName = "binary_search.s";
    insertCodes();
    parseLabel(fileName);
    ifstream inFile;
    inFile.open(fileName);
    ofstream outFile;
    outFile.open("binary_search.coe");
    outFile << "memory_initialization_radix=2;" << '\n';
    outFile << "memory_initialization_vector=" << '\n';

    for (string line; getline(inFile, line);)
    {

        if (line == "" || line[0] == '#')
            continue;
        string ans;
        string op1 = "";
        int opend;
        int found = 0;
        for (int i = 0; i < line.size(); ++i)
        {
            if (line[i] == ':')
            {
                found = 1;
                break;
            }
            if (line[i] == ' ')
            {
                opend = i;
                break;
            }
            op1 += line[i];
        }
        if (found)
            continue;
        if (line[0] == 'b')
        {

            string label = "";
            int lblend = 0;
            for (int i = line.size() - 1; i >= 0; --i)
            {
                if (line[i] == ',' || line[i] == ' ' || line[i] == '\n')
                {
                    lblend = i;
                    break;
                }
                label += line[i];
            }
            reverse(label.begin(), label.end());
            string new_line = line.substr(0, lblend + 1);

            ans += opcode[op1];
            cout << op1 << " " << opcode[op1] << "\t";
            cout << label << " " << labelMap[label] << "\t";
            if (op1 == "b" || op1 == "bl" || op1 == "bcy" || op1 == "bncy")
            {
                ans += (bitset<26>(labelMap[label]).to_string());
                cout << (bitset<26>(labelMap[label]).to_string()) << endl;
            }
            else
            {
                string rs = "";
                for (int i = opend + 1; i < line.size(); ++i)
                {
                    if (line[i] == ',')
                        break;
                    rs += line[i];
                }
                cout << rs << " " << regs[rs] << " \t";
                ans += (bitset<5>(regs[rs]).to_string());
                if (op1 == "br")
                {
                    ans += bitset<21>(0).to_string();
                    cout << (bitset<21>(0).to_string()) << endl;
                }
                else
                {
                    ans += (bitset<21>(labelMap[label]).to_string());
                    cout << (bitset<21>(labelMap[label]).to_string()) << endl;
                }
            }
        }
        else
        {
            ans = getCode(line);
        }
        outFile << ans << ",\n";
    }
}