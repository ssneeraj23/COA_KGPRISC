/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "reg0 = %d\t, reg1 = %d\t, reg2 = %d\t, reg3 = %d\t, reg4 = %d\t, reg5 = %d\t, reg6 = %d\t, reg11 = %d\t, reg12 = %d\t";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static int ng3[] = {2, 0};
static int ng4[] = {3, 0};
static int ng5[] = {4, 0};
static int ng6[] = {5, 0};
static int ng7[] = {6, 0};
static int ng8[] = {11, 0};
static int ng9[] = {12, 0};
static const char *ng10 = "/home/neeraj/Desktop/KGPRISC/KGPRISC/final_main.v";

void Monitor_42_2(char *);
void Monitor_42_2(char *);


static void Monitor_42_2_Func(char *t0)
{
    char t6[8];
    char t21[8];
    char t36[8];
    char t51[8];
    char t66[8];
    char t81[8];
    char t96[8];
    char t111[8];
    char t126[8];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t75;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    char *t92;
    char *t93;
    char *t94;
    char *t95;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    char *t101;
    char *t102;
    char *t103;
    char *t104;
    char *t105;
    char *t107;
    char *t108;
    char *t109;
    char *t110;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;
    char *t119;
    char *t120;
    char *t122;
    char *t123;
    char *t124;
    char *t125;
    char *t127;
    char *t128;
    char *t129;
    char *t130;
    char *t131;
    char *t132;
    char *t133;
    char *t134;
    char *t135;

LAB0:    t2 = (t0 + 5064);
    t3 = *((char **)t2);
    t4 = ((((char*)(t3))) + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 5088);
    t8 = *((char **)t7);
    t9 = ((((char*)(t8))) + 72U);
    t10 = *((char **)t9);
    t11 = (t0 + 5112);
    t12 = *((char **)t11);
    t13 = ((((char*)(t12))) + 64U);
    t14 = *((char **)t13);
    t15 = ((char*)((ng1)));
    xsi_vlog_generic_get_array_select_value(t6, 32, t5, t10, t14, 2, 1, t15, 32, 1);
    t17 = (t0 + 5136);
    t18 = *((char **)t17);
    t19 = ((((char*)(t18))) + 56U);
    t20 = *((char **)t19);
    t22 = (t0 + 5160);
    t23 = *((char **)t22);
    t24 = ((((char*)(t23))) + 72U);
    t25 = *((char **)t24);
    t26 = (t0 + 5184);
    t27 = *((char **)t26);
    t28 = ((((char*)(t27))) + 64U);
    t29 = *((char **)t28);
    t30 = ((char*)((ng2)));
    xsi_vlog_generic_get_array_select_value(t21, 32, t20, t25, t29, 2, 1, t30, 32, 1);
    t32 = (t0 + 5208);
    t33 = *((char **)t32);
    t34 = ((((char*)(t33))) + 56U);
    t35 = *((char **)t34);
    t37 = (t0 + 5232);
    t38 = *((char **)t37);
    t39 = ((((char*)(t38))) + 72U);
    t40 = *((char **)t39);
    t41 = (t0 + 5256);
    t42 = *((char **)t41);
    t43 = ((((char*)(t42))) + 64U);
    t44 = *((char **)t43);
    t45 = ((char*)((ng3)));
    xsi_vlog_generic_get_array_select_value(t36, 32, t35, t40, t44, 2, 1, t45, 32, 1);
    t47 = (t0 + 5280);
    t48 = *((char **)t47);
    t49 = ((((char*)(t48))) + 56U);
    t50 = *((char **)t49);
    t52 = (t0 + 5304);
    t53 = *((char **)t52);
    t54 = ((((char*)(t53))) + 72U);
    t55 = *((char **)t54);
    t56 = (t0 + 5328);
    t57 = *((char **)t56);
    t58 = ((((char*)(t57))) + 64U);
    t59 = *((char **)t58);
    t60 = ((char*)((ng4)));
    xsi_vlog_generic_get_array_select_value(t51, 32, t50, t55, t59, 2, 1, t60, 32, 1);
    t62 = (t0 + 5352);
    t63 = *((char **)t62);
    t64 = ((((char*)(t63))) + 56U);
    t65 = *((char **)t64);
    t67 = (t0 + 5376);
    t68 = *((char **)t67);
    t69 = ((((char*)(t68))) + 72U);
    t70 = *((char **)t69);
    t71 = (t0 + 5400);
    t72 = *((char **)t71);
    t73 = ((((char*)(t72))) + 64U);
    t74 = *((char **)t73);
    t75 = ((char*)((ng5)));
    xsi_vlog_generic_get_array_select_value(t66, 32, t65, t70, t74, 2, 1, t75, 32, 1);
    t77 = (t0 + 5424);
    t78 = *((char **)t77);
    t79 = ((((char*)(t78))) + 56U);
    t80 = *((char **)t79);
    t82 = (t0 + 5448);
    t83 = *((char **)t82);
    t84 = ((((char*)(t83))) + 72U);
    t85 = *((char **)t84);
    t86 = (t0 + 5472);
    t87 = *((char **)t86);
    t88 = ((((char*)(t87))) + 64U);
    t89 = *((char **)t88);
    t90 = ((char*)((ng6)));
    xsi_vlog_generic_get_array_select_value(t81, 32, t80, t85, t89, 2, 1, t90, 32, 1);
    t92 = (t0 + 5496);
    t93 = *((char **)t92);
    t94 = ((((char*)(t93))) + 56U);
    t95 = *((char **)t94);
    t97 = (t0 + 5520);
    t98 = *((char **)t97);
    t99 = ((((char*)(t98))) + 72U);
    t100 = *((char **)t99);
    t101 = (t0 + 5544);
    t102 = *((char **)t101);
    t103 = ((((char*)(t102))) + 64U);
    t104 = *((char **)t103);
    t105 = ((char*)((ng7)));
    xsi_vlog_generic_get_array_select_value(t96, 32, t95, t100, t104, 2, 1, t105, 32, 1);
    t107 = (t0 + 5568);
    t108 = *((char **)t107);
    t109 = ((((char*)(t108))) + 56U);
    t110 = *((char **)t109);
    t112 = (t0 + 5592);
    t113 = *((char **)t112);
    t114 = ((((char*)(t113))) + 72U);
    t115 = *((char **)t114);
    t116 = (t0 + 5616);
    t117 = *((char **)t116);
    t118 = ((((char*)(t117))) + 64U);
    t119 = *((char **)t118);
    t120 = ((char*)((ng8)));
    xsi_vlog_generic_get_array_select_value(t111, 32, t110, t115, t119, 2, 1, t120, 32, 1);
    t122 = (t0 + 5640);
    t123 = *((char **)t122);
    t124 = ((((char*)(t123))) + 56U);
    t125 = *((char **)t124);
    t127 = (t0 + 5664);
    t128 = *((char **)t127);
    t129 = ((((char*)(t128))) + 72U);
    t130 = *((char **)t129);
    t131 = (t0 + 5688);
    t132 = *((char **)t131);
    t133 = ((((char*)(t132))) + 64U);
    t134 = *((char **)t133);
    t135 = ((char*)((ng9)));
    xsi_vlog_generic_get_array_select_value(t126, 32, t125, t130, t134, 2, 1, t135, 32, 1);
    xsi_vlogfile_write(1, 0, 3, ng0, 10, t0, (char)119, t6, 32, (char)119, t21, 32, (char)119, t36, 32, (char)119, t51, 32, (char)119, t66, 32, (char)119, t81, 32, (char)119, t96, 32, (char)119, t111, 32, (char)119, t126, 32);

LAB1:    return;
}

static void Always_40_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 2520U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng10);
    t2 = (t0 + 2328);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(40, ng10);
    t4 = (t0 + 1448);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB8;

LAB6:    if (*((unsigned int *)t7) == 0)
        goto LAB5;

LAB7:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB8:    t14 = (t3 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t3) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB10;

LAB9:    t22 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 1448);
    xsi_vlogvar_assign_value(t24, t3, 0, 0, 1);
    goto LAB2;

LAB5:    *((unsigned int *)t3) = 1;
    goto LAB8;

LAB10:    t18 = *((unsigned int *)t3);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t3) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB9;

}

static void Initial_41_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;

LAB0:    t1 = (t0 + 2768U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(41, ng10);

LAB4:    xsi_set_current_line(42, ng10);
    Monitor_42_2(t0);
    xsi_set_current_line(54, ng10);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1448);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(55, ng10);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(58, ng10);
    t2 = (t0 + 2576);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(59, ng10);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1608);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB1;

}

void Monitor_42_2(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 2824);
    t2 = (t0 + 3336);
    xsi_vlogfile_monitor((void *)Monitor_42_2_Func, t1, t2);

LAB1:    return;
}


extern void work_m_09518291084091789882_2292360090_init()
{
	static char *pe[] = {(void *)Always_40_0,(void *)Initial_41_1,(void *)Monitor_42_2};
	xsi_register_didat("work_m_09518291084091789882_2292360090", "isim/final_main_isim_beh.exe.sim/work/m_09518291084091789882_2292360090.didat");
	xsi_register_executes(pe);
}
