/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    xilinxcorelib_ver_m_04284627112054182733_4086976548_init();
    xilinxcorelib_ver_m_04284627112054182733_1283051207_init();
    xilinxcorelib_ver_m_18166792875774041790_0135474683_init();
    xilinxcorelib_ver_m_17738287534884592592_1878299745_init();
    xilinxcorelib_ver_m_10066368518302646626_1885025853_init();
    work_m_10431123694831851113_3258266500_init();
    work_m_04062719426249757624_1720460815_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_04062719426249757624_1720460815");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
