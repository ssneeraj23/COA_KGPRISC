/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "reg0 = %d, reg1 = %d, reg2 = %d, reg3 = %d, reg4 = %d, reg5 = %d, reg6 = %d, reg7 = %d, reg8 = %d, reg9 = %d, reg10 = %d, reg11 = %d, reg12 = %d, reg13 = %d, reg14 = %d, reg15 = %d, reg16 = %d, reg17 = %d,reg31= %d";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static int ng3[] = {2, 0};
static int ng4[] = {3, 0};
static int ng5[] = {4, 0};
static int ng6[] = {5, 0};
static int ng7[] = {6, 0};
static int ng8[] = {7, 0};
static int ng9[] = {8, 0};
static int ng10[] = {9, 0};
static int ng11[] = {10, 0};
static int ng12[] = {11, 0};
static int ng13[] = {12, 0};
static int ng14[] = {13, 0};
static int ng15[] = {14, 0};
static int ng16[] = {15, 0};
static int ng17[] = {16, 0};
static int ng18[] = {17, 0};
static int ng19[] = {20, 0};
static int ng20[] = {31, 0};
static const char *ng21 = "/home/neeraj/Desktop/KGPRISC/KGPRISC/sub_main_tb.v";

void Monitor_133_5(char *);
void Monitor_133_5(char *);


static void Monitor_133_5_Func(char *t0)
{
    char t6[8];
    char t21[8];
    char t36[8];
    char t51[8];
    char t66[8];
    char t81[8];
    char t96[8];
    char t111[8];
    char t126[8];
    char t141[8];
    char t156[8];
    char t171[8];
    char t186[8];
    char t201[8];
    char t216[8];
    char t231[8];
    char t246[8];
    char t261[8];
    char t276[8];
    char t291[8];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t75;
    char *t77;
    char *t78;
    char *t79;
    char *t80;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    char *t92;
    char *t93;
    char *t94;
    char *t95;
    char *t97;
    char *t98;
    char *t99;
    char *t100;
    char *t101;
    char *t102;
    char *t103;
    char *t104;
    char *t105;
    char *t107;
    char *t108;
    char *t109;
    char *t110;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;
    char *t119;
    char *t120;
    char *t122;
    char *t123;
    char *t124;
    char *t125;
    char *t127;
    char *t128;
    char *t129;
    char *t130;
    char *t131;
    char *t132;
    char *t133;
    char *t134;
    char *t135;
    char *t137;
    char *t138;
    char *t139;
    char *t140;
    char *t142;
    char *t143;
    char *t144;
    char *t145;
    char *t146;
    char *t147;
    char *t148;
    char *t149;
    char *t150;
    char *t152;
    char *t153;
    char *t154;
    char *t155;
    char *t157;
    char *t158;
    char *t159;
    char *t160;
    char *t161;
    char *t162;
    char *t163;
    char *t164;
    char *t165;
    char *t167;
    char *t168;
    char *t169;
    char *t170;
    char *t172;
    char *t173;
    char *t174;
    char *t175;
    char *t176;
    char *t177;
    char *t178;
    char *t179;
    char *t180;
    char *t182;
    char *t183;
    char *t184;
    char *t185;
    char *t187;
    char *t188;
    char *t189;
    char *t190;
    char *t191;
    char *t192;
    char *t193;
    char *t194;
    char *t195;
    char *t197;
    char *t198;
    char *t199;
    char *t200;
    char *t202;
    char *t203;
    char *t204;
    char *t205;
    char *t206;
    char *t207;
    char *t208;
    char *t209;
    char *t210;
    char *t212;
    char *t213;
    char *t214;
    char *t215;
    char *t217;
    char *t218;
    char *t219;
    char *t220;
    char *t221;
    char *t222;
    char *t223;
    char *t224;
    char *t225;
    char *t227;
    char *t228;
    char *t229;
    char *t230;
    char *t232;
    char *t233;
    char *t234;
    char *t235;
    char *t236;
    char *t237;
    char *t238;
    char *t239;
    char *t240;
    char *t242;
    char *t243;
    char *t244;
    char *t245;
    char *t247;
    char *t248;
    char *t249;
    char *t250;
    char *t251;
    char *t252;
    char *t253;
    char *t254;
    char *t255;
    char *t257;
    char *t258;
    char *t259;
    char *t260;
    char *t262;
    char *t263;
    char *t264;
    char *t265;
    char *t266;
    char *t267;
    char *t268;
    char *t269;
    char *t270;
    char *t272;
    char *t273;
    char *t274;
    char *t275;
    char *t277;
    char *t278;
    char *t279;
    char *t280;
    char *t281;
    char *t282;
    char *t283;
    char *t284;
    char *t285;
    char *t287;
    char *t288;
    char *t289;
    char *t290;
    char *t292;
    char *t293;
    char *t294;
    char *t295;
    char *t296;
    char *t297;
    char *t298;
    char *t299;
    char *t300;

LAB0:    t2 = (t0 + 10984);
    t3 = *((char **)t2);
    t4 = ((((char*)(t3))) + 56U);
    t5 = *((char **)t4);
    t7 = (t0 + 11008);
    t8 = *((char **)t7);
    t9 = ((((char*)(t8))) + 72U);
    t10 = *((char **)t9);
    t11 = (t0 + 11032);
    t12 = *((char **)t11);
    t13 = ((((char*)(t12))) + 64U);
    t14 = *((char **)t13);
    t15 = ((char*)((ng1)));
    xsi_vlog_generic_get_array_select_value(t6, 32, t5, t10, t14, 2, 1, t15, 32, 1);
    t17 = (t0 + 11056);
    t18 = *((char **)t17);
    t19 = ((((char*)(t18))) + 56U);
    t20 = *((char **)t19);
    t22 = (t0 + 11080);
    t23 = *((char **)t22);
    t24 = ((((char*)(t23))) + 72U);
    t25 = *((char **)t24);
    t26 = (t0 + 11104);
    t27 = *((char **)t26);
    t28 = ((((char*)(t27))) + 64U);
    t29 = *((char **)t28);
    t30 = ((char*)((ng2)));
    xsi_vlog_generic_get_array_select_value(t21, 32, t20, t25, t29, 2, 1, t30, 32, 1);
    t32 = (t0 + 11128);
    t33 = *((char **)t32);
    t34 = ((((char*)(t33))) + 56U);
    t35 = *((char **)t34);
    t37 = (t0 + 11152);
    t38 = *((char **)t37);
    t39 = ((((char*)(t38))) + 72U);
    t40 = *((char **)t39);
    t41 = (t0 + 11176);
    t42 = *((char **)t41);
    t43 = ((((char*)(t42))) + 64U);
    t44 = *((char **)t43);
    t45 = ((char*)((ng3)));
    xsi_vlog_generic_get_array_select_value(t36, 32, t35, t40, t44, 2, 1, t45, 32, 1);
    t47 = (t0 + 11200);
    t48 = *((char **)t47);
    t49 = ((((char*)(t48))) + 56U);
    t50 = *((char **)t49);
    t52 = (t0 + 11224);
    t53 = *((char **)t52);
    t54 = ((((char*)(t53))) + 72U);
    t55 = *((char **)t54);
    t56 = (t0 + 11248);
    t57 = *((char **)t56);
    t58 = ((((char*)(t57))) + 64U);
    t59 = *((char **)t58);
    t60 = ((char*)((ng4)));
    xsi_vlog_generic_get_array_select_value(t51, 32, t50, t55, t59, 2, 1, t60, 32, 1);
    t62 = (t0 + 11272);
    t63 = *((char **)t62);
    t64 = ((((char*)(t63))) + 56U);
    t65 = *((char **)t64);
    t67 = (t0 + 11296);
    t68 = *((char **)t67);
    t69 = ((((char*)(t68))) + 72U);
    t70 = *((char **)t69);
    t71 = (t0 + 11320);
    t72 = *((char **)t71);
    t73 = ((((char*)(t72))) + 64U);
    t74 = *((char **)t73);
    t75 = ((char*)((ng5)));
    xsi_vlog_generic_get_array_select_value(t66, 32, t65, t70, t74, 2, 1, t75, 32, 1);
    t77 = (t0 + 11344);
    t78 = *((char **)t77);
    t79 = ((((char*)(t78))) + 56U);
    t80 = *((char **)t79);
    t82 = (t0 + 11368);
    t83 = *((char **)t82);
    t84 = ((((char*)(t83))) + 72U);
    t85 = *((char **)t84);
    t86 = (t0 + 11392);
    t87 = *((char **)t86);
    t88 = ((((char*)(t87))) + 64U);
    t89 = *((char **)t88);
    t90 = ((char*)((ng6)));
    xsi_vlog_generic_get_array_select_value(t81, 32, t80, t85, t89, 2, 1, t90, 32, 1);
    t92 = (t0 + 11416);
    t93 = *((char **)t92);
    t94 = ((((char*)(t93))) + 56U);
    t95 = *((char **)t94);
    t97 = (t0 + 11440);
    t98 = *((char **)t97);
    t99 = ((((char*)(t98))) + 72U);
    t100 = *((char **)t99);
    t101 = (t0 + 11464);
    t102 = *((char **)t101);
    t103 = ((((char*)(t102))) + 64U);
    t104 = *((char **)t103);
    t105 = ((char*)((ng7)));
    xsi_vlog_generic_get_array_select_value(t96, 32, t95, t100, t104, 2, 1, t105, 32, 1);
    t107 = (t0 + 11488);
    t108 = *((char **)t107);
    t109 = ((((char*)(t108))) + 56U);
    t110 = *((char **)t109);
    t112 = (t0 + 11512);
    t113 = *((char **)t112);
    t114 = ((((char*)(t113))) + 72U);
    t115 = *((char **)t114);
    t116 = (t0 + 11536);
    t117 = *((char **)t116);
    t118 = ((((char*)(t117))) + 64U);
    t119 = *((char **)t118);
    t120 = ((char*)((ng8)));
    xsi_vlog_generic_get_array_select_value(t111, 32, t110, t115, t119, 2, 1, t120, 32, 1);
    t122 = (t0 + 11560);
    t123 = *((char **)t122);
    t124 = ((((char*)(t123))) + 56U);
    t125 = *((char **)t124);
    t127 = (t0 + 11584);
    t128 = *((char **)t127);
    t129 = ((((char*)(t128))) + 72U);
    t130 = *((char **)t129);
    t131 = (t0 + 11608);
    t132 = *((char **)t131);
    t133 = ((((char*)(t132))) + 64U);
    t134 = *((char **)t133);
    t135 = ((char*)((ng9)));
    xsi_vlog_generic_get_array_select_value(t126, 32, t125, t130, t134, 2, 1, t135, 32, 1);
    t137 = (t0 + 11632);
    t138 = *((char **)t137);
    t139 = ((((char*)(t138))) + 56U);
    t140 = *((char **)t139);
    t142 = (t0 + 11656);
    t143 = *((char **)t142);
    t144 = ((((char*)(t143))) + 72U);
    t145 = *((char **)t144);
    t146 = (t0 + 11680);
    t147 = *((char **)t146);
    t148 = ((((char*)(t147))) + 64U);
    t149 = *((char **)t148);
    t150 = ((char*)((ng10)));
    xsi_vlog_generic_get_array_select_value(t141, 32, t140, t145, t149, 2, 1, t150, 32, 1);
    t152 = (t0 + 11704);
    t153 = *((char **)t152);
    t154 = ((((char*)(t153))) + 56U);
    t155 = *((char **)t154);
    t157 = (t0 + 11728);
    t158 = *((char **)t157);
    t159 = ((((char*)(t158))) + 72U);
    t160 = *((char **)t159);
    t161 = (t0 + 11752);
    t162 = *((char **)t161);
    t163 = ((((char*)(t162))) + 64U);
    t164 = *((char **)t163);
    t165 = ((char*)((ng11)));
    xsi_vlog_generic_get_array_select_value(t156, 32, t155, t160, t164, 2, 1, t165, 32, 1);
    t167 = (t0 + 11776);
    t168 = *((char **)t167);
    t169 = ((((char*)(t168))) + 56U);
    t170 = *((char **)t169);
    t172 = (t0 + 11800);
    t173 = *((char **)t172);
    t174 = ((((char*)(t173))) + 72U);
    t175 = *((char **)t174);
    t176 = (t0 + 11824);
    t177 = *((char **)t176);
    t178 = ((((char*)(t177))) + 64U);
    t179 = *((char **)t178);
    t180 = ((char*)((ng12)));
    xsi_vlog_generic_get_array_select_value(t171, 32, t170, t175, t179, 2, 1, t180, 32, 1);
    t182 = (t0 + 11848);
    t183 = *((char **)t182);
    t184 = ((((char*)(t183))) + 56U);
    t185 = *((char **)t184);
    t187 = (t0 + 11872);
    t188 = *((char **)t187);
    t189 = ((((char*)(t188))) + 72U);
    t190 = *((char **)t189);
    t191 = (t0 + 11896);
    t192 = *((char **)t191);
    t193 = ((((char*)(t192))) + 64U);
    t194 = *((char **)t193);
    t195 = ((char*)((ng13)));
    xsi_vlog_generic_get_array_select_value(t186, 32, t185, t190, t194, 2, 1, t195, 32, 1);
    t197 = (t0 + 11920);
    t198 = *((char **)t197);
    t199 = ((((char*)(t198))) + 56U);
    t200 = *((char **)t199);
    t202 = (t0 + 11944);
    t203 = *((char **)t202);
    t204 = ((((char*)(t203))) + 72U);
    t205 = *((char **)t204);
    t206 = (t0 + 11968);
    t207 = *((char **)t206);
    t208 = ((((char*)(t207))) + 64U);
    t209 = *((char **)t208);
    t210 = ((char*)((ng14)));
    xsi_vlog_generic_get_array_select_value(t201, 32, t200, t205, t209, 2, 1, t210, 32, 1);
    t212 = (t0 + 11992);
    t213 = *((char **)t212);
    t214 = ((((char*)(t213))) + 56U);
    t215 = *((char **)t214);
    t217 = (t0 + 12016);
    t218 = *((char **)t217);
    t219 = ((((char*)(t218))) + 72U);
    t220 = *((char **)t219);
    t221 = (t0 + 12040);
    t222 = *((char **)t221);
    t223 = ((((char*)(t222))) + 64U);
    t224 = *((char **)t223);
    t225 = ((char*)((ng15)));
    xsi_vlog_generic_get_array_select_value(t216, 32, t215, t220, t224, 2, 1, t225, 32, 1);
    t227 = (t0 + 12064);
    t228 = *((char **)t227);
    t229 = ((((char*)(t228))) + 56U);
    t230 = *((char **)t229);
    t232 = (t0 + 12088);
    t233 = *((char **)t232);
    t234 = ((((char*)(t233))) + 72U);
    t235 = *((char **)t234);
    t236 = (t0 + 12112);
    t237 = *((char **)t236);
    t238 = ((((char*)(t237))) + 64U);
    t239 = *((char **)t238);
    t240 = ((char*)((ng16)));
    xsi_vlog_generic_get_array_select_value(t231, 32, t230, t235, t239, 2, 1, t240, 32, 1);
    t242 = (t0 + 12136);
    t243 = *((char **)t242);
    t244 = ((((char*)(t243))) + 56U);
    t245 = *((char **)t244);
    t247 = (t0 + 12160);
    t248 = *((char **)t247);
    t249 = ((((char*)(t248))) + 72U);
    t250 = *((char **)t249);
    t251 = (t0 + 12184);
    t252 = *((char **)t251);
    t253 = ((((char*)(t252))) + 64U);
    t254 = *((char **)t253);
    t255 = ((char*)((ng17)));
    xsi_vlog_generic_get_array_select_value(t246, 32, t245, t250, t254, 2, 1, t255, 32, 1);
    t257 = (t0 + 12208);
    t258 = *((char **)t257);
    t259 = ((((char*)(t258))) + 56U);
    t260 = *((char **)t259);
    t262 = (t0 + 12232);
    t263 = *((char **)t262);
    t264 = ((((char*)(t263))) + 72U);
    t265 = *((char **)t264);
    t266 = (t0 + 12256);
    t267 = *((char **)t266);
    t268 = ((((char*)(t267))) + 64U);
    t269 = *((char **)t268);
    t270 = ((char*)((ng18)));
    xsi_vlog_generic_get_array_select_value(t261, 32, t260, t265, t269, 2, 1, t270, 32, 1);
    t272 = (t0 + 12280);
    t273 = *((char **)t272);
    t274 = ((((char*)(t273))) + 56U);
    t275 = *((char **)t274);
    t277 = (t0 + 12304);
    t278 = *((char **)t277);
    t279 = ((((char*)(t278))) + 72U);
    t280 = *((char **)t279);
    t281 = (t0 + 12328);
    t282 = *((char **)t281);
    t283 = ((((char*)(t282))) + 64U);
    t284 = *((char **)t283);
    t285 = ((char*)((ng19)));
    xsi_vlog_generic_get_array_select_value(t276, 32, t275, t280, t284, 2, 1, t285, 32, 1);
    t287 = (t0 + 12352);
    t288 = *((char **)t287);
    t289 = ((((char*)(t288))) + 56U);
    t290 = *((char **)t289);
    t292 = (t0 + 12376);
    t293 = *((char **)t292);
    t294 = ((((char*)(t293))) + 72U);
    t295 = *((char **)t294);
    t296 = (t0 + 12400);
    t297 = *((char **)t296);
    t298 = ((((char*)(t297))) + 64U);
    t299 = *((char **)t298);
    t300 = ((char*)((ng20)));
    xsi_vlog_generic_get_array_select_value(t291, 32, t290, t295, t299, 2, 1, t300, 32, 1);
    xsi_vlogfile_write(1, 0, 3, ng0, 21, t0, (char)119, t6, 32, (char)119, t21, 32, (char)119, t36, 32, (char)119, t51, 32, (char)119, t66, 32, (char)119, t81, 32, (char)119, t96, 32, (char)119, t111, 32, (char)119, t126, 32, (char)119, t141, 32, (char)119, t156, 32, (char)119, t171, 32, (char)119, t186, 32, (char)119, t201, 32, (char)119, t216, 32, (char)119, t231, 32, (char)119, t246, 32, (char)119, t261, 32, (char)119, t276, 32, (char)119, t291, 32);

LAB1:    return;
}

static void Cont_38_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t13[8];
    char t17[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t14;
    char *t15;
    char *t16;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;

LAB0:    t1 = (t0 + 5880U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(38, ng21);
    t2 = (t0 + 1528U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t6 = (t5 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (t7 >> 0);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t6);
    t10 = (t9 >> 0);
    *((unsigned int *)t2) = t10;
    t11 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t11 & 65535U);
    t12 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t12 & 65535U);
    t14 = ((char*)((ng17)));
    t15 = (t0 + 1528U);
    t16 = *((char **)t15);
    memset(t17, 0, 8);
    t15 = (t17 + 4);
    t18 = (t16 + 4);
    t19 = *((unsigned int *)t16);
    t20 = (t19 >> 15);
    t21 = (t20 & 1);
    *((unsigned int *)t17) = t21;
    t22 = *((unsigned int *)t18);
    t23 = (t22 >> 15);
    t24 = (t23 & 1);
    *((unsigned int *)t15) = t24;
    xsi_vlog_mul_concat(t13, 16, 1, t14, 1U, t17, 1);
    xsi_vlogtype_concat(t3, 32, 32, 2U, t13, 16, t4, 16);
    t25 = (t0 + 7568);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    memcpy(t29, t3, 8);
    xsi_driver_vfirst_trans(t25, 0, 31);
    t30 = (t0 + 7440);
    *((int *)t30) = 1;

LAB1:    return;
}

static void Cont_41_1(char *t0)
{
    char t3[8];
    char t4[8];
    char t13[8];
    char t17[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t14;
    char *t15;
    char *t16;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;

LAB0:    t1 = (t0 + 6128U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(41, ng21);
    t2 = (t0 + 1528U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t6 = (t5 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (t7 >> 5);
    *((unsigned int *)t4) = t8;
    t9 = *((unsigned int *)t6);
    t10 = (t9 >> 5);
    *((unsigned int *)t2) = t10;
    t11 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t11 & 65535U);
    t12 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t12 & 65535U);
    t14 = ((char*)((ng17)));
    t15 = (t0 + 1528U);
    t16 = *((char **)t15);
    memset(t17, 0, 8);
    t15 = (t17 + 4);
    t18 = (t16 + 4);
    t19 = *((unsigned int *)t16);
    t20 = (t19 >> 20);
    t21 = (t20 & 1);
    *((unsigned int *)t17) = t21;
    t22 = *((unsigned int *)t18);
    t23 = (t22 >> 20);
    t24 = (t23 & 1);
    *((unsigned int *)t15) = t24;
    xsi_vlog_mul_concat(t13, 16, 1, t14, 1U, t17, 1);
    xsi_vlogtype_concat(t3, 32, 32, 2U, t13, 16, t4, 16);
    t25 = (t0 + 7632);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    memcpy(t29, t3, 8);
    xsi_driver_vfirst_trans(t25, 0, 31);
    t30 = (t0 + 7456);
    *((int *)t30) = 1;

LAB1:    return;
}

static void Cont_44_2(char *t0)
{
    char t3[8];
    char t4[8];
    char *t1;
    char *t2;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    t1 = (t0 + 6376U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(44, ng21);
    t2 = (t0 + 3608U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t12);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB8;

LAB9:    t18 = *((unsigned int *)t4);
    t19 = (~(t18));
    t20 = *((unsigned int *)t12);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t12) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t22, 8);

LAB16:    t16 = (t0 + 7696);
    t23 = (t16 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memcpy(t26, t3, 8);
    xsi_driver_vfirst_trans(t16, 0, 31);
    t27 = (t0 + 7472);
    *((int *)t27) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t11 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB7;

LAB8:    t16 = (t0 + 2648U);
    t17 = *((char **)t16);
    goto LAB9;

LAB10:    t16 = (t0 + 2008U);
    t22 = *((char **)t16);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 32, t17, 32, t22, 32);
    goto LAB16;

LAB14:    memcpy(t3, t17, 8);
    goto LAB16;

}

static void Always_129_3(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 6624U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(129, ng21);
    t2 = (t0 + 6432);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(129, ng21);
    t4 = (t0 + 4808);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB8;

LAB6:    if (*((unsigned int *)t7) == 0)
        goto LAB5;

LAB7:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB8:    t14 = (t3 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t3) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB10;

LAB9:    t22 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 4808);
    xsi_vlogvar_assign_value(t24, t3, 0, 0, 1);
    goto LAB2;

LAB5:    *((unsigned int *)t3) = 1;
    goto LAB8;

LAB10:    t18 = *((unsigned int *)t3);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t3) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB9;

}

static void Initial_131_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;

LAB0:    t1 = (t0 + 6872U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(131, ng21);

LAB4:    xsi_set_current_line(133, ng21);
    Monitor_133_5(t0);
    xsi_set_current_line(155, ng21);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4808);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(156, ng21);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4968);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(158, ng21);
    t2 = (t0 + 6680);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(161, ng21);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4968);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB1;

}

void Monitor_133_5(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 6928);
    t2 = (t0 + 7488);
    xsi_vlogfile_monitor((void *)Monitor_133_5_Func, t1, t2);

LAB1:    return;
}


extern void work_m_04808585214174110529_1125057791_init()
{
	static char *pe[] = {(void *)Cont_38_0,(void *)Cont_41_1,(void *)Cont_44_2,(void *)Always_129_3,(void *)Initial_131_4,(void *)Monitor_133_5};
	xsi_register_didat("work_m_04808585214174110529_1125057791", "isim/sub_main_tb_isim_beh.exe.sim/work/m_04808585214174110529_1125057791.didat");
	xsi_register_executes(pe);
}
