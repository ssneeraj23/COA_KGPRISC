/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/neeraj/Desktop/KGPRISC/KGPRISC/alu.v";
static int ng1[] = {0, 0};
static int ng2[] = {3, 0};
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {1U, 0U};
static int ng5[] = {1, 0};
static int ng6[] = {2, 0};
static unsigned int ng7[] = {2U, 0U};
static unsigned int ng8[] = {3U, 0U};
static unsigned int ng9[] = {4U, 0U};
static unsigned int ng10[] = {5U, 0U};
static unsigned int ng11[] = {6U, 0U};
static unsigned int ng12[] = {7U, 0U};



static void NetDecl_43_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;

LAB0:    t1 = (t0 + 4232U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5144);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t7, 0, 8);
    t8 = 1U;
    t9 = t8;
    t10 = (t2 + 4);
    t11 = *((unsigned int *)t2);
    t8 = (t8 & t11);
    t12 = *((unsigned int *)t10);
    t9 = (t9 & t12);
    t13 = (t7 + 4);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 | t8);
    t15 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t15 | t9);
    xsi_driver_vfirst_trans(t3, 0, 0U);

LAB1:    return;
}

static void Cont_45_1(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t11[8];
    char t38[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;

LAB0:    t1 = (t0 + 4480U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 1800U);
    t5 = *((char **)t2);
    t2 = (t0 + 1760U);
    t7 = (t2 + 72U);
    t8 = *((char **)t7);
    t9 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t6, 32, t5, t8, 2, t9, 32, 1);
    t10 = ((char*)((ng1)));
    memset(t11, 0, 8);
    t12 = (t6 + 4);
    t13 = (t10 + 4);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t10);
    t16 = (t14 ^ t15);
    t17 = *((unsigned int *)t12);
    t18 = *((unsigned int *)t13);
    t19 = (t17 ^ t18);
    t20 = (t16 | t19);
    t21 = *((unsigned int *)t12);
    t22 = *((unsigned int *)t13);
    t23 = (t21 | t22);
    t24 = (~(t23));
    t25 = (t20 & t24);
    if (t25 != 0)
        goto LAB7;

LAB4:    if (t23 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t11) = 1;

LAB7:    memset(t4, 0, 8);
    t27 = (t11 + 4);
    t28 = *((unsigned int *)t27);
    t29 = (~(t28));
    t30 = *((unsigned int *)t11);
    t31 = (t30 & t29);
    t32 = (t31 & 1U);
    if (t32 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t27) != 0)
        goto LAB10;

LAB11:    t34 = (t4 + 4);
    t35 = *((unsigned int *)t4);
    t36 = *((unsigned int *)t34);
    t37 = (t35 || t36);
    if (t37 > 0)
        goto LAB12;

LAB13:    t41 = *((unsigned int *)t4);
    t42 = (~(t41));
    t43 = *((unsigned int *)t34);
    t44 = (t42 || t43);
    if (t44 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t34) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t46, 8);

LAB20:    t45 = (t0 + 5208);
    t47 = (t45 + 56U);
    t48 = *((char **)t47);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    memcpy(t50, t3, 8);
    xsi_driver_vfirst_trans(t45, 0, 31);
    t51 = (t0 + 5048);
    *((int *)t51) = 1;

LAB1:    return;
LAB6:    t26 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    t33 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t33) = 1;
    goto LAB11;

LAB12:    t39 = (t0 + 1640U);
    t40 = *((char **)t39);
    t39 = ((char*)((ng3)));
    xsi_vlogtype_concat(t38, 32, 32, 2U, t39, 27, t40, 5);
    goto LAB13;

LAB14:    t45 = (t0 + 1480U);
    t46 = *((char **)t45);
    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 32, t38, 32, t46, 32);
    goto LAB20;

LAB18:    memcpy(t3, t38, 8);
    goto LAB20;

}

static void Always_52_2(char *t0)
{
    char t4[8];
    char t5[8];
    char t8[8];
    char t42[8];
    char t55[8];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    char *t41;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    unsigned int t48;
    int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t56;
    int t57;
    int t58;

LAB0:    t1 = (t0 + 4728U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 5064);
    *((int *)t2) = 1;
    t3 = (t0 + 4760);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(52, ng0);

LAB5:    xsi_set_current_line(53, ng0);
    t6 = (t0 + 1320U);
    t7 = *((char **)t6);
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    t9 = (t7 + 4);
    t10 = (t6 + 4);
    t11 = *((unsigned int *)t7);
    t12 = *((unsigned int *)t6);
    t13 = (t11 ^ t12);
    t14 = *((unsigned int *)t9);
    t15 = *((unsigned int *)t10);
    t16 = (t14 ^ t15);
    t17 = (t13 | t16);
    t18 = *((unsigned int *)t9);
    t19 = *((unsigned int *)t10);
    t20 = (t18 | t19);
    t21 = (~(t20));
    t22 = (t17 & t21);
    if (t22 != 0)
        goto LAB9;

LAB6:    if (t20 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t8) = 1;

LAB9:    memset(t5, 0, 8);
    t24 = (t8 + 4);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t8);
    t28 = (t27 & t26);
    t29 = (t28 & 1U);
    if (t29 != 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t24) != 0)
        goto LAB12;

LAB13:    t31 = (t5 + 4);
    t32 = *((unsigned int *)t5);
    t33 = *((unsigned int *)t31);
    t34 = (t32 || t33);
    if (t34 > 0)
        goto LAB14;

LAB15:    t36 = *((unsigned int *)t5);
    t37 = (~(t36));
    t38 = *((unsigned int *)t31);
    t39 = (t37 || t38);
    if (t39 > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t31) > 0)
        goto LAB18;

LAB19:    if (*((unsigned int *)t5) > 0)
        goto LAB20;

LAB21:    memcpy(t4, t40, 8);

LAB22:    t41 = (t0 + 3320);
    t43 = (t0 + 3320);
    t44 = (t43 + 72U);
    t45 = *((char **)t44);
    t46 = ((char*)((ng1)));
    xsi_vlog_generic_convert_bit_index(t42, t45, 2, t46, 32, 1);
    t47 = (t42 + 4);
    t48 = *((unsigned int *)t47);
    t49 = (!(t48));
    if (t49 == 1)
        goto LAB23;

LAB24:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 1320U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t8 + 4);
    t6 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (t11 >> 31);
    t13 = (t12 & 1);
    *((unsigned int *)t8) = t13;
    t14 = *((unsigned int *)t6);
    t15 = (t14 >> 31);
    t16 = (t15 & 1);
    *((unsigned int *)t2) = t16;
    t7 = ((char*)((ng4)));
    memset(t42, 0, 8);
    t9 = (t8 + 4);
    t10 = (t7 + 4);
    t17 = *((unsigned int *)t8);
    t18 = *((unsigned int *)t7);
    t19 = (t17 ^ t18);
    t20 = *((unsigned int *)t9);
    t21 = *((unsigned int *)t10);
    t22 = (t20 ^ t21);
    t25 = (t19 | t22);
    t26 = *((unsigned int *)t9);
    t27 = *((unsigned int *)t10);
    t28 = (t26 | t27);
    t29 = (~(t28));
    t32 = (t25 & t29);
    if (t32 != 0)
        goto LAB28;

LAB25:    if (t28 != 0)
        goto LAB27;

LAB26:    *((unsigned int *)t42) = 1;

LAB28:    memset(t5, 0, 8);
    t24 = (t42 + 4);
    t33 = *((unsigned int *)t24);
    t34 = (~(t33));
    t36 = *((unsigned int *)t42);
    t37 = (t36 & t34);
    t38 = (t37 & 1U);
    if (t38 != 0)
        goto LAB29;

LAB30:    if (*((unsigned int *)t24) != 0)
        goto LAB31;

LAB32:    t31 = (t5 + 4);
    t39 = *((unsigned int *)t5);
    t48 = *((unsigned int *)t31);
    t50 = (t39 || t48);
    if (t50 > 0)
        goto LAB33;

LAB34:    t51 = *((unsigned int *)t5);
    t52 = (~(t51));
    t53 = *((unsigned int *)t31);
    t54 = (t52 || t53);
    if (t54 > 0)
        goto LAB35;

LAB36:    if (*((unsigned int *)t31) > 0)
        goto LAB37;

LAB38:    if (*((unsigned int *)t5) > 0)
        goto LAB39;

LAB40:    memcpy(t4, t40, 8);

LAB41:    t41 = (t0 + 3320);
    t43 = (t0 + 3320);
    t44 = (t43 + 72U);
    t45 = *((char **)t44);
    t46 = ((char*)((ng5)));
    xsi_vlog_generic_convert_bit_index(t55, t45, 2, t46, 32, 1);
    t47 = (t55 + 4);
    t56 = *((unsigned int *)t47);
    t49 = (!(t56));
    if (t49 == 1)
        goto LAB42;

LAB43:    xsi_set_current_line(55, ng0);
    t2 = (t0 + 1800U);
    t3 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t4 + 4);
    t6 = (t3 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (t11 >> 0);
    *((unsigned int *)t4) = t12;
    t13 = *((unsigned int *)t6);
    t14 = (t13 >> 0);
    *((unsigned int *)t2) = t14;
    t15 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t15 & 7U);
    t16 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t16 & 7U);

LAB44:    t7 = ((char*)((ng3)));
    t49 = xsi_vlog_unsigned_case_compare(t4, 3, t7, 3);
    if (t49 == 1)
        goto LAB45;

LAB46:    t2 = ((char*)((ng4)));
    t49 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t49 == 1)
        goto LAB47;

LAB48:    t2 = ((char*)((ng7)));
    t49 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t49 == 1)
        goto LAB49;

LAB50:    t2 = ((char*)((ng8)));
    t49 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t49 == 1)
        goto LAB51;

LAB52:    t2 = ((char*)((ng9)));
    t49 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t49 == 1)
        goto LAB53;

LAB54:    t2 = ((char*)((ng10)));
    t49 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t49 == 1)
        goto LAB55;

LAB56:    t2 = ((char*)((ng11)));
    t49 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t49 == 1)
        goto LAB57;

LAB58:    t2 = ((char*)((ng12)));
    t49 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t49 == 1)
        goto LAB59;

LAB60:
LAB62:
LAB61:    xsi_set_current_line(97, ng0);

LAB96:    xsi_set_current_line(98, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3160);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(99, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3320);
    t6 = (t0 + 3320);
    t7 = (t6 + 72U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t5, t9, 2, t10, 32, 1);
    t23 = (t5 + 4);
    t11 = *((unsigned int *)t23);
    t49 = (!(t11));
    if (t49 == 1)
        goto LAB97;

LAB98:
LAB63:    goto LAB2;

LAB8:    t23 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB9;

LAB10:    *((unsigned int *)t5) = 1;
    goto LAB13;

LAB12:    t30 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB13;

LAB14:    t35 = ((char*)((ng4)));
    goto LAB15;

LAB16:    t40 = ((char*)((ng3)));
    goto LAB17;

LAB18:    xsi_vlog_unsigned_bit_combine(t4, 1, t35, 1, t40, 1);
    goto LAB22;

LAB20:    memcpy(t4, t35, 8);
    goto LAB22;

LAB23:    xsi_vlogvar_assign_value(t41, t4, 0, *((unsigned int *)t42), 1);
    goto LAB24;

LAB27:    t23 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB28;

LAB29:    *((unsigned int *)t5) = 1;
    goto LAB32;

LAB31:    t30 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB32;

LAB33:    t35 = ((char*)((ng4)));
    goto LAB34;

LAB35:    t40 = ((char*)((ng3)));
    goto LAB36;

LAB37:    xsi_vlog_unsigned_bit_combine(t4, 1, t35, 1, t40, 1);
    goto LAB41;

LAB39:    memcpy(t4, t35, 8);
    goto LAB41;

LAB42:    xsi_vlogvar_assign_value(t41, t4, 0, *((unsigned int *)t55), 1);
    goto LAB43;

LAB45:    xsi_set_current_line(57, ng0);

LAB64:    xsi_set_current_line(58, ng0);
    t9 = (t0 + 1320U);
    t10 = *((char **)t9);
    t9 = (t0 + 1480U);
    t23 = *((char **)t9);
    memset(t5, 0, 8);
    xsi_vlog_unsigned_add(t5, 32, t10, 32, t23, 32);
    t9 = (t0 + 3160);
    xsi_vlogvar_assign_value(t9, t5, 0, 0, 32);
    xsi_set_current_line(59, ng0);
    t2 = (t0 + 2440U);
    t3 = *((char **)t2);
    t2 = (t0 + 3320);
    t6 = (t0 + 3320);
    t7 = (t6 + 72U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t5, t9, 2, t10, 32, 1);
    t23 = (t5 + 4);
    t11 = *((unsigned int *)t23);
    t49 = (!(t11));
    if (t49 == 1)
        goto LAB65;

LAB66:    goto LAB63;

LAB47:    xsi_set_current_line(62, ng0);

LAB67:    xsi_set_current_line(63, ng0);
    t3 = (t0 + 1480U);
    t6 = *((char **)t3);
    memset(t5, 0, 8);
    t3 = (t5 + 4);
    t7 = (t6 + 4);
    t11 = *((unsigned int *)t6);
    t12 = (~(t11));
    *((unsigned int *)t5) = t12;
    *((unsigned int *)t3) = 0;
    if (*((unsigned int *)t7) != 0)
        goto LAB69;

LAB68:    t17 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t17 & 4294967295U);
    t18 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t18 & 4294967295U);
    t9 = ((char*)((ng4)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 32, t5, 32, t9, 32);
    t10 = (t0 + 3160);
    xsi_vlogvar_assign_value(t10, t8, 0, 0, 32);
    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3320);
    t6 = (t0 + 3320);
    t7 = (t6 + 72U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t5, t9, 2, t10, 32, 1);
    t23 = (t5 + 4);
    t11 = *((unsigned int *)t23);
    t49 = (!(t11));
    if (t49 == 1)
        goto LAB70;

LAB71:    goto LAB63;

LAB49:    xsi_set_current_line(67, ng0);

LAB72:    xsi_set_current_line(68, ng0);
    t3 = (t0 + 2760U);
    t6 = *((char **)t3);
    t3 = (t0 + 3160);
    xsi_vlogvar_assign_value(t3, t6, 0, 0, 32);
    xsi_set_current_line(69, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3320);
    t6 = (t0 + 3320);
    t7 = (t6 + 72U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t5, t9, 2, t10, 32, 1);
    t23 = (t5 + 4);
    t11 = *((unsigned int *)t23);
    t49 = (!(t11));
    if (t49 == 1)
        goto LAB73;

LAB74:    goto LAB63;

LAB51:    xsi_set_current_line(72, ng0);

LAB75:    xsi_set_current_line(73, ng0);
    t3 = (t0 + 1320U);
    t6 = *((char **)t3);
    t3 = (t0 + 1480U);
    t7 = *((char **)t3);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t7);
    t13 = (t11 & t12);
    *((unsigned int *)t5) = t13;
    t3 = (t6 + 4);
    t9 = (t7 + 4);
    t10 = (t5 + 4);
    t14 = *((unsigned int *)t3);
    t15 = *((unsigned int *)t9);
    t16 = (t14 | t15);
    *((unsigned int *)t10) = t16;
    t17 = *((unsigned int *)t10);
    t18 = (t17 != 0);
    if (t18 == 1)
        goto LAB76;

LAB77:
LAB78:    t30 = (t0 + 3160);
    xsi_vlogvar_assign_value(t30, t5, 0, 0, 32);
    xsi_set_current_line(74, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3320);
    t6 = (t0 + 3320);
    t7 = (t6 + 72U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t5, t9, 2, t10, 32, 1);
    t23 = (t5 + 4);
    t11 = *((unsigned int *)t23);
    t49 = (!(t11));
    if (t49 == 1)
        goto LAB79;

LAB80:    goto LAB63;

LAB53:    xsi_set_current_line(77, ng0);

LAB81:    xsi_set_current_line(78, ng0);
    t3 = (t0 + 1320U);
    t6 = *((char **)t3);
    t3 = (t0 + 1480U);
    t7 = *((char **)t3);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t7);
    t13 = (t11 ^ t12);
    *((unsigned int *)t5) = t13;
    t3 = (t6 + 4);
    t9 = (t7 + 4);
    t10 = (t5 + 4);
    t14 = *((unsigned int *)t3);
    t15 = *((unsigned int *)t9);
    t16 = (t14 | t15);
    *((unsigned int *)t10) = t16;
    t17 = *((unsigned int *)t10);
    t18 = (t17 != 0);
    if (t18 == 1)
        goto LAB82;

LAB83:
LAB84:    t23 = (t0 + 3160);
    xsi_vlogvar_assign_value(t23, t5, 0, 0, 32);
    xsi_set_current_line(79, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3320);
    t6 = (t0 + 3320);
    t7 = (t6 + 72U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t5, t9, 2, t10, 32, 1);
    t23 = (t5 + 4);
    t11 = *((unsigned int *)t23);
    t49 = (!(t11));
    if (t49 == 1)
        goto LAB85;

LAB86:    goto LAB63;

LAB55:    xsi_set_current_line(82, ng0);

LAB87:    xsi_set_current_line(83, ng0);
    t3 = (t0 + 1320U);
    t6 = *((char **)t3);
    t3 = (t0 + 2280U);
    t7 = *((char **)t3);
    memset(t5, 0, 8);
    xsi_vlog_unsigned_lshift(t5, 32, t6, 32, t7, 32);
    t3 = (t0 + 3160);
    xsi_vlogvar_assign_value(t3, t5, 0, 0, 32);
    xsi_set_current_line(84, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3320);
    t6 = (t0 + 3320);
    t7 = (t6 + 72U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t5, t9, 2, t10, 32, 1);
    t23 = (t5 + 4);
    t11 = *((unsigned int *)t23);
    t49 = (!(t11));
    if (t49 == 1)
        goto LAB88;

LAB89:    goto LAB63;

LAB57:    xsi_set_current_line(87, ng0);

LAB90:    xsi_set_current_line(88, ng0);
    t3 = (t0 + 1320U);
    t6 = *((char **)t3);
    t3 = (t0 + 2280U);
    t7 = *((char **)t3);
    memset(t5, 0, 8);
    xsi_vlog_unsigned_rshift(t5, 32, t6, 32, t7, 32);
    t3 = (t0 + 3160);
    xsi_vlogvar_assign_value(t3, t5, 0, 0, 32);
    xsi_set_current_line(89, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3320);
    t6 = (t0 + 3320);
    t7 = (t6 + 72U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t5, t9, 2, t10, 32, 1);
    t23 = (t5 + 4);
    t11 = *((unsigned int *)t23);
    t49 = (!(t11));
    if (t49 == 1)
        goto LAB91;

LAB92:    goto LAB63;

LAB59:    xsi_set_current_line(92, ng0);

LAB93:    xsi_set_current_line(93, ng0);
    t3 = (t0 + 1320U);
    t6 = *((char **)t3);
    t3 = (t0 + 2280U);
    t7 = *((char **)t3);
    memset(t8, 0, 8);
    xsi_vlog_signed_arith_rshift(t8, 32, t6, 32, t7, 32);
    t3 = (t0 + 3160);
    xsi_vlogvar_assign_value(t3, t8, 0, 0, 32);
    xsi_set_current_line(94, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3320);
    t6 = (t0 + 3320);
    t7 = (t6 + 72U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t5, t9, 2, t10, 32, 1);
    t23 = (t5 + 4);
    t11 = *((unsigned int *)t23);
    t49 = (!(t11));
    if (t49 == 1)
        goto LAB94;

LAB95:    goto LAB63;

LAB65:    xsi_vlogvar_assign_value(t2, t3, 0, *((unsigned int *)t5), 1);
    goto LAB66;

LAB69:    t13 = *((unsigned int *)t5);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t5) = (t13 | t14);
    t15 = *((unsigned int *)t3);
    t16 = *((unsigned int *)t7);
    *((unsigned int *)t3) = (t15 | t16);
    goto LAB68;

LAB70:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t5), 1);
    goto LAB71;

LAB73:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t5), 1);
    goto LAB74;

LAB76:    t19 = *((unsigned int *)t5);
    t20 = *((unsigned int *)t10);
    *((unsigned int *)t5) = (t19 | t20);
    t23 = (t6 + 4);
    t24 = (t7 + 4);
    t21 = *((unsigned int *)t6);
    t22 = (~(t21));
    t25 = *((unsigned int *)t23);
    t26 = (~(t25));
    t27 = *((unsigned int *)t7);
    t28 = (~(t27));
    t29 = *((unsigned int *)t24);
    t32 = (~(t29));
    t57 = (t22 & t26);
    t58 = (t28 & t32);
    t33 = (~(t57));
    t34 = (~(t58));
    t36 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t36 & t33);
    t37 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t37 & t34);
    t38 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t38 & t33);
    t39 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t39 & t34);
    goto LAB78;

LAB79:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t5), 1);
    goto LAB80;

LAB82:    t19 = *((unsigned int *)t5);
    t20 = *((unsigned int *)t10);
    *((unsigned int *)t5) = (t19 | t20);
    goto LAB84;

LAB85:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t5), 1);
    goto LAB86;

LAB88:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t5), 1);
    goto LAB89;

LAB91:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t5), 1);
    goto LAB92;

LAB94:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t5), 1);
    goto LAB95;

LAB97:    xsi_vlogvar_assign_value(t3, t2, 0, *((unsigned int *)t5), 1);
    goto LAB98;

}


extern void work_m_03593125230170082339_0886308060_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Cont_45_1,(void *)Always_52_2};
	xsi_register_didat("work_m_03593125230170082339_0886308060", "isim/sub_main_tb_isim_beh.exe.sim/work/m_03593125230170082339_0886308060.didat");
	xsi_register_executes(pe);
}
