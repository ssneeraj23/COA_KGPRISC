/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_08732214055330907366_1733234252_init();
    work_m_18096879424178325292_3948285920_init();
    work_m_03593125230170082339_0886308060_init();
    work_m_09859164920413153038_2314087575_init();
    work_m_07282051779476963092_2397809620_init();
    xilinxcorelib_ver_m_04284627112054182733_1283051207_init();
    xilinxcorelib_ver_m_18166792875774041790_0135474683_init();
    xilinxcorelib_ver_m_17738287534884592592_3097340675_init();
    xilinxcorelib_ver_m_10066368518302646626_2861010056_init();
    work_m_05240187959938530918_2556329580_init();
    work_m_11312852531590580258_2123150820_init();
    xilinxcorelib_ver_m_04284627112054182733_4086976548_init();
    xilinxcorelib_ver_m_17738287534884592592_1878299745_init();
    xilinxcorelib_ver_m_10066368518302646626_1885025853_init();
    work_m_10431123694831851113_3258266500_init();
    work_m_04062719426249757624_1720460815_init();
    work_m_17016478477831366953_0531866297_init();
    work_m_14722951814826808813_0520159928_init();
    work_m_12169163691201955762_3991497499_init();
    work_m_04808585214174110529_1125057791_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_04808585214174110529_1125057791");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
