/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000000111936742_1733234252_init();
    work_m_00000000001966704428_3948285920_init();
    work_m_00000000001010812393_0886308060_init();
    work_m_00000000001329063694_2314087575_init();
    work_m_00000000004021927700_2397809620_init();
    xilinxcorelib_ver_m_00000000001358910285_1283051207_init();
    xilinxcorelib_ver_m_00000000001687936702_0135474683_init();
    xilinxcorelib_ver_m_00000000000277421008_3097340675_init();
    xilinxcorelib_ver_m_00000000001603977570_2861010056_init();
    work_m_00000000002489990758_2556329580_init();
    work_m_00000000002111162402_2123150820_init();
    xilinxcorelib_ver_m_00000000001358910285_4086976548_init();
    xilinxcorelib_ver_m_00000000000277421008_1878299745_init();
    xilinxcorelib_ver_m_00000000001603977570_1885025853_init();
    work_m_00000000003869038185_3258266500_init();
    work_m_00000000004289860536_1720460815_init();
    work_m_00000000003073894697_0531866297_init();
    work_m_00000000002280773101_0520159928_init();
    work_m_00000000004088170418_3991497499_init();
    work_m_00000000002064327489_1125057791_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002064327489_1125057791");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
