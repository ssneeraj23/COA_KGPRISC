/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    xilinxcorelib_ver_m_00000000001358910285_0056288886_init();
    xilinxcorelib_ver_m_00000000001687936702_3463246476_init();
    xilinxcorelib_ver_m_00000000000277421008_2591781873_init();
    xilinxcorelib_ver_m_00000000003435484244_0145266643_init();
    work_m_00000000002489990758_4285754678_init();
    work_m_00000000000659289167_2123150820_init();
    work_m_00000000004021927700_2397809620_init();
    work_m_00000000000535765384_2071126179_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000000535765384_2071126179");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
